function injectScript() {
  const script = document.createElement('script');
  script.textContent = `
(() => {
  // Kiểm tra xem đã inject chưa
  if (window.__streamOptimizerInjected) return;
  window.__streamOptimizerInjected = true;

  const CHUNK_SIZE = 512;
  const RENDER_DELAY = 16;
  const MAX_QUEUE = 50;
  
  const css = \`
    .lm-stream{contain:content;will-change:contents}
    .lm-chunk{display:inline}
    pre,code{font-family:monospace!important;white-space:pre-wrap!important}
    [class*="cursor"]{animation:none!important}
  \`;
  
  const style = document.createElement('style');
  style.textContent = css;
  document.head.appendChild(style);
  
  class StreamOptimizer {
    constructor() {
      this.queue = [];
      this.rendering = false;
      this.targetEl = null;
      this.buffer = '';
      this.decoder = new TextDecoder();
      this.lastRender = 0;
    }
    
    processChunk(chunk) {
      if (typeof chunk === 'string') {
        this.buffer += chunk;
      } else {
        this.buffer += this.decoder.decode(chunk, { stream: true });
      }
      
      while (this.buffer.length >= CHUNK_SIZE) {
        this.queue.push(this.buffer.slice(0, CHUNK_SIZE));
        this.buffer = this.buffer.slice(CHUNK_SIZE);
        
        if (this.queue.length > MAX_QUEUE) {
          const merged = this.queue.splice(0, MAX_QUEUE/2).join('');
          this.queue.unshift(merged);
        }
      }
      
      if (!this.rendering) {
        this.render();
      }
    }
    
    render() {
      const now = performance.now();
      const delay = Math.max(0, RENDER_DELAY - (now - this.lastRender));
      
      if (delay > 0) {
        setTimeout(() => this.render(), delay);
        return;
      }
      
      this.rendering = true;
      this.lastRender = now;
      
      requestAnimationFrame(() => {
        if (!this.targetEl) {
          this.targetEl = this.findStreamTarget();
          if (this.targetEl) {
            this.targetEl.classList.add('lm-stream');
          }
        }
        
        if (this.targetEl && this.queue.length > 0) {
          const chunk = this.queue.shift();
          const span = document.createElement('span');
          span.className = 'lm-chunk';
          span.textContent = chunk;
          this.targetEl.appendChild(span);
          
          if (this.targetEl.children.length > 100) {
            const text = this.targetEl.textContent;
            this.targetEl.textContent = text;
          }
        }
        
        this.rendering = false;
        
        if (this.queue.length > 0 || this.buffer.length > 0) {
          this.render();
        }
      });
    }
    
    findStreamTarget() {
      const selectors = [
        '.message:last-child .content',
        '[class*="streaming"] [class*="content"]',
        '.ai-message:last-child',
        '[data-streaming="true"]',
        // Thêm selector cho Claude.ai
        '.font-claude-message:last-child',
        '.prose:last-child'
      ];
      
      for (const sel of selectors) {
        try {
          const el = document.querySelector(sel);
          if (el) return el;
        } catch (e) {}
      }
      
      return null;
    }
    
    finish() {
      if (this.buffer.length > 0) {
        this.queue.push(this.buffer);
        this.buffer = '';
      }
      
      this.render();
      
      setTimeout(() => {
        if (this.targetEl) {
          this.targetEl.classList.remove('lm-stream');
          const text = this.targetEl.textContent;
          this.targetEl.textContent = text;
        }
        this.reset();
      }, 100);
    }
    
    reset() {
      this.queue = [];
      this.buffer = '';
      this.targetEl = null;
      this.rendering = false;
    }
  }
  
  const optimizer = new StreamOptimizer();
  
  // Override fetch
  const originalFetch = window.fetch;
  window.fetch = async function(...args) {
    const response = await originalFetch.apply(this, args);
    
    if (!response.body || !response.headers.get('content-type')?.includes('stream')) {
      return response;
    }
    
    const reader = response.body.getReader();
    const stream = new ReadableStream({
      async start(controller) {
        try {
          while (true) {
            const { done, value } = await reader.read();
            
            if (done) {
              optimizer.finish();
              controller.close();
              break;
            }
            
            optimizer.processChunk(value);
            controller.enqueue(value);
          }
        } catch (error) {
          controller.error(error);
        }
      }
    });
    
    return new Response(stream, {
      headers: response.headers,
      status: response.status,
      statusText: response.statusText
    });
  };
  
  // Override EventSource
  const originalEventSource = window.EventSource;
  window.EventSource = class extends originalEventSource {
    constructor(...args) {
      super(...args);
      
      this.addEventListener('message', (event) => {
        if (event.data) {
          try {
            const data = JSON.parse(event.data);
            if (data.content || data.text || data.chunk) {
              optimizer.processChunk(data.content || data.text || data.chunk);
            }
          } catch {
            optimizer.processChunk(event.data);
          }
        }
      });
      
      this.addEventListener('error', () => {
        optimizer.finish();
      });
    }
  };
  
  // Override WebSocket
  const handleWebSocket = (ws) => {
    const originalSend = ws.send;
    ws.send = function(...args) {
      optimizer.reset();
      return originalSend.apply(this, args);
    };
    
    ws.addEventListener('message', (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'stream' || data.content) {
          optimizer.processChunk(data.content || data.text || '');
        }
      } catch {
        optimizer.processChunk(event.data);
      }
    });
  };
  
  const originalWebSocket = window.WebSocket;
  window.WebSocket = class extends originalWebSocket {
    constructor(...args) {
      super(...args);
      handleWebSocket(this);
    }
  };
})();
  `;
  
  (document.head || document.documentElement).appendChild(script);
  script.remove();
}

// Inject ngay khi có thể
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', injectScript);
} else {
  injectScript();
}

// Backup injection cho SPA
setTimeout(injectScript, 100);